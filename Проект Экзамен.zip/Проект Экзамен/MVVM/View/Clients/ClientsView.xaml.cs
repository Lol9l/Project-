﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Clients;

/// <summary>
/// Interaction logic for ClientsView.xaml
/// </summary>
public partial class ClientsView : UserControl
{
    public ClientsView()
    {
        InitializeComponent();
    }
}
