﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Penalties
{
    /// <summary>
    /// Interaction logic for PenaltiesUpdateView.xaml
    /// </summary>
    public partial class PenaltiesUpdateView : UserControl
    {
        public PenaltiesUpdateView()
        {
            InitializeComponent();
        }
    }
}
