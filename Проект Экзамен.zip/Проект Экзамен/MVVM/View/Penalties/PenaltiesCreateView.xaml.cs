﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Penalties
{
    /// <summary>
    /// Interaction logic for PenaltiesCreateView.xaml
    /// </summary>
    public partial class PenaltiesCreateView : UserControl
    {
        public PenaltiesCreateView()
        {
            InitializeComponent();
        }
    }
}
