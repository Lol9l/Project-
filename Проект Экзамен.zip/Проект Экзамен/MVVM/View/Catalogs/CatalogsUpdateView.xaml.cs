﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Catalogs
{
    /// <summary>
    /// Interaction logic for CatalogsUpdateView.xaml
    /// </summary>
    public partial class CatalogsUpdateView : UserControl
    {
        public CatalogsUpdateView()
        {
            InitializeComponent();
        }
    }
}
