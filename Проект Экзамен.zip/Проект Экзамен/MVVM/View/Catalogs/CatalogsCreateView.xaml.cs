﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Catalogs
{
    /// <summary>
    /// Interaction logic for CatalogsCreateView.xaml
    /// </summary>
    public partial class CatalogsCreateView : UserControl
    {
        public CatalogsCreateView()
        {
            InitializeComponent();
        }
    }
}
