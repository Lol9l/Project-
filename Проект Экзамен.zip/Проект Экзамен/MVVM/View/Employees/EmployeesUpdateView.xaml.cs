﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Employees
{
    /// <summary>
    /// Interaction logic for EmployeesUpdateView.xaml
    /// </summary>
    public partial class EmployeesUpdateView : UserControl
    {
        public EmployeesUpdateView()
        {
            InitializeComponent();
        }
    }
}
