﻿namespace Travel_Company.WPF.Core.Enums;

public enum CatalogType
{
    None,
    Country,
    Street,
    Hotel,
    Place
}