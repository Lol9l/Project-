﻿namespace Travel_Company.WPF.Models;

public interface ICatalogItem
{
    public string Name { get; set; }
}