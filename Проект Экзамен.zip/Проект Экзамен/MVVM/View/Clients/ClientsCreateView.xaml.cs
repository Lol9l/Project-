﻿using System.Windows.Controls;

namespace Travel_Company.WPF.MVVM.View.Clients
{
    /// <summary>
    /// Interaction logic for ClientsCreateView.xaml
    /// </summary>
    public partial class ClientsCreateView : UserControl
    {
        public ClientsCreateView()
        {
            InitializeComponent();
        }
    }
}
